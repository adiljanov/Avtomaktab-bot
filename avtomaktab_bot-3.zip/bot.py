import telebot
import json

TOKEN = "8107742536:AAHw-hsLfwqK9Nr3C5mJlQ_bXCRpbaqfADY"
bot = telebot.TeleBot(TOKEN)

with open("questions.json", "r", encoding="utf-8") as f:
    questions = json.load(f)

@bot.message_handler(commands=["start"])
def start_message(message):
    bot.send_message(message.chat.id, "Avtomaktab test botiga xush kelibsiz! Savolingizni kiriting:")

@bot.message_handler(func=lambda message: True)
def answer_question(message):
    user_question = message.text.lower()
    answer = questions.get(user_question, "Kechirasiz, bu savol bo‘yicha ma'lumot topilmadi.")
    bot.send_message(message.chat.id, answer)

bot.polling()
